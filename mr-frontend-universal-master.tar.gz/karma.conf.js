// Look in ./config for karma.conf.js
module.exports = require('./test-config/karma.conf.js');
