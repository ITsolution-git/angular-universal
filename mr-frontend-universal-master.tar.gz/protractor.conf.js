// look in ./config for protractor.conf.js
exports.config = require('./test-config/protractor.conf.js').config;