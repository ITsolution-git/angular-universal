export interface User {
  readonly id?: number | string;
  readonly name?: string;
}
