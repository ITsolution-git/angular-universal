export const views: Object[] = [
  {
    name: 'Dashboard',
    icon: 'home',
    link: ['']
  },
  {
    name: 'Lazy',
    icon: 'file_download',
    link: ['lazy']
  },
  {
    name: 'Bad Link',
    icon: 'error',
    link: ['wronglink']
  }
];
