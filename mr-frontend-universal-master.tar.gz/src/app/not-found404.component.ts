import { Component } from '@angular/core';
@Component({
  selector: 'my-not-found',
  template: '<h3>Error 404: Not found</h3>'
})

export class NotFound404Component { }
