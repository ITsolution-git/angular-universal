// Routes with html5pushstate
// ensure routes match client-side-app
export const routes: string[] = [
  '',
  'lazy',
  'sync',
  'wronglink'
];
