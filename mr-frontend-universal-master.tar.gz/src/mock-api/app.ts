import { data } from './data';

export class App {
  getData() {
    return data;
  }
}
