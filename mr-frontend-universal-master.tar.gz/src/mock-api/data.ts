export const data = {
  greeting: 'Hello',
  name: 'World'
};
